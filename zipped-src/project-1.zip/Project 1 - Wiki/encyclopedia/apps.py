from django.apps import AppConfig


class EncyclopediaConfig(AppConfig):
    name = 'encyclopedia'
